package com.example.barcodescanapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class  ScannerActivity extends AppCompatActivity {

    private EditText etBarCode;
    private TextView textViewBarCode;
    //private TextView textView2;

    private EditText barName;
    private EditText brandName;
    private EditText energyLevels;

    private EditText etCategory;
    private EditText etSugar;
    private

    String mainBarCode;

    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);

        mQueue = Volley.newRequestQueue(this);

        textViewBarCode = findViewById(R.id.textViewBarcode);

        barName = findViewById(R.id.editTextBarName);
        brandName = findViewById(R.id.editTextBrandName);
        energyLevels = findViewById(R.id.editTextEnergy);

        etCategory = findViewById(R.id.editTextCategory);
        etSugar = findViewById(R.id.editTextSugar);
        //textView2 = findViewById(R.id.textView2);

        //String barCode = getIntent().getStringExtra("keyName");
        //textView2.setText(barCode);
        //textViewBarCode.setText(barCode);

        //textViewBarCode = findViewById(R.id.textViewBarcode);

        String barCode1 = getIntent().getStringExtra("keyName");
        etBarCode = findViewById(R.id.editTextBarCode);
        etBarCode.setText(barCode1);

        if(etBarCode!=null){
            getDetails(barCode1); //parameter as(myBarCode)
        }
        //getDetails3(barCode1);


        // jsonParse();
        //getDetails();


    }

    private void getDetails(String barCode){

        String url = "https://api.edamam.com/api/food-database/v2/parser?app_id=c0dccf80&app_key=afbfe7f98e06228fe0e17b8e13af8fef&upc="+barCode+"&nutrition-type=cooking";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("hints");

                            for(int i = 0; i < jsonArray.length(); i++){
                                JSONObject jo1 = jsonArray.getJSONObject(i);
                                JSONObject foodObject = jsonArray.getJSONObject(0).getJSONObject("food");
                                JSONObject nutrientsObject = foodObject.getJSONObject("nutrients");
                                //JSONObject foodObject = (JSONObject)jo1.get("food");
                                //JSONObject nutrientObject = (JSONObject) jo1.get("nutrients");


                                String foodLabel = foodObject.getString("label");
                                barName.setText(foodLabel);

                                String brand = foodObject.getString("brand");
                                brandName.setText(brand);

                                String energy = nutrientsObject.getString("ENERC_KCAL");
                                energyLevels.setText(energy);

                                String category = foodObject.getString("category");
                                etCategory.setText(category);

                                String sugarLevels = nutrientsObject.getString("SUGAR");
                                etSugar.setText(sugarLevels);

                                //double energy = Double.parseDouble(nutrientObject.getString("FAT"));
                                //energyLevels.setText((int) energy);

                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        //barName.setText(response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);

    }

    /*private void getDetails2(String barCode1){
        String url = "https://api.edamam.com/api/food-database/v2/parser?app_id=c0dccf80&app_key=afbfe7f98e06228fe0e17b8e13af8fef&upc="+barCode1+"&nutrition-type=cooking";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("hints");

                            for(int i = 0; i < jsonArray.length(); i++){

                                JSONObject foodObject = jsonArray.getJSONObject(0).getJSONObject("food");
                                JSONObject nutrientsObject = foodObject.getJSONObject("nutrients");
                                //JSONObject jo1 = jsonArray.getJSONObject(i);
                                //JSONObject nutrientObject = (JSONObject)jo1.get("nutrients");
                                //JSONObject nutrientObject = (JSONObject) jo1.get("nutrients");

                                double energy = nutrientsObject.getDouble("ENERC_KCAL");
                                energyLevels.setText((int) energy);


                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        //barName.setText(response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);

    }*/

    /*private void getDetails3(String barCode2){
        String url = "https://api.edamam.com/api/food-database/v2/parser?app_id=c0dccf80&app_key=afbfe7f98e06228fe0e17b8e13af8fef&upc="+barCode2+"&nutrition-type=cooking";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray hintsArray = jsonObject.getJSONArray("hints");
                            JSONObject foodObject = hintsArray.getJSONObject(0).getJSONObject("food");
                            JSONObject nutrientsObject = foodObject.getJSONObject("nutrients");


                            double enerc_kcal = nutrientsObject.getDouble("ENERC_KCAL");
                            double fat = nutrientsObject.getDouble("FAT");
                            double fasat = nutrientsObject.getDouble("FASAT");
                            double chocdf = nutrientsObject.getDouble("CHOCDF");
                            double sugar = nutrientsObject.getDouble("SUGAR");
                            double procnt = nutrientsObject.getDouble("PROCNT");
                            double na = nutrientsObject.getDouble("NA");

                            energyLevels.setText((int) enerc_kcal);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("VOLLEY", error.getMessage());
            }
        });

        mQueue.add(stringRequest);
    }*/



}